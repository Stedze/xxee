[![Discord](https://img.shields.io/discord/975068703559409685?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/xvirustool)
![Show me the code](https://github.com/Xvirus0/Xvirus-Tools/assets/89728480/d7538665-19f2-405d-bb38-d7ccbd7be0fd)


<h1 align="center">[API-Tool]- XVirus</h1>
<p align="center">
  <a href="https://github.com/Xvirus0/Xvirus-Tools/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/License-MIT-important">
  </a>
  <a href="https://www.python.org">
    <img src="https://img.shields.io/badge/Python-3.9-informational.svg">
  </a>
  <a href="https://github.com/Xvirus0/Xvirus-Tools">
    <img src="https://img.shields.io/badge/covarage-70%25-yellow">
</p>

Welcome to Xvirus's repo!
My goal is to show how fragile and insecure the Discord API is.

**NOTE:** This is the free version of Xvirus and wont be updated frequently

**NOTE 2:** We're currently looking for resellers of our [premium](https://xvirus.pro/) version, if this interests you please join our [discord](https://discord.gg/xvirustool).

## Disclaimer

|Xvirus was made for Educational purposes|
|-------------------------------------------------|
This project was created only for good purposes and personal use.
By using Xvirus, you agree that you hold responsibility and accountability of any consequences caused by your actions.

## How to install 
 clone the repository: 
```shell
git clone --recursive https://github.com/Xvirus0/Xvirus-Tools.git
```
Then enter the directory:
```shell
cd Xvirus-Tools
```
Finally just run Setup.bat and wait for it to complete.


# Contact [(discord)](https://discord.gg/xvirustool)

* @dexvmaster

* @adminxfr

* @bodypsy
<!-- The machine is now active. Recovery protocol initiated. Please stand by! -->
